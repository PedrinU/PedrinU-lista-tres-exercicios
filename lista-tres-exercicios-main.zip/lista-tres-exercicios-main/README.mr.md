# Lista-dois-java-una
Lista dois de exercícios em JAVA


perfil no [linkedin]https://www.linkedin.com/in/pedro-meira-6a4448264/

# Tecnologias-atualizadas
[JDK](https://www.oracle.com/java/technologies/javase/jdk17-archive-downloads.html)

[VSCODE](https://code.visualstudio.com/download)
